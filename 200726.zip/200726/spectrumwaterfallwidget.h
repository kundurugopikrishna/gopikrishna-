#ifndef SPECTRUMWATERFALLWIDGET_H
#define SPECTRUMWATERFALLWIDGET_H

#include <QWidget>
#include <QVector>
#include <QQueue>

class SpectrumWaterfallWidget : public QWidget {
    Q_OBJECT
public:
    explicit SpectrumWaterfallWidget(QWidget *parent = nullptr);
    void addSpectrum(const QVector<int> &data);
    void clearHistory();

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<int> currentSpectrum;
    QQueue<QVector<int>> spectrumHistory;
    int maxHistory;

    QColor mapColor(int intensity) const;
};

#endif // SPECTRUMWATERFALLWIDGET_H
