#ifndef SPECTRUMWIDGET_H
#define SPECTRUMWIDGET_H

#include <headers.h>
#include <unistd.h>
#include <qfontmetrics.h>

class SpectrumWidget : public QWidget
{
  Q_OBJECT

public:
  explicit SpectrumWidget(QWidget *parent = nullptr);
  QSize sizeHint() const override;

  void updateSpectrumData(const QVector<double> &freq, const QVector<double> &power);
  void setStartStop(float startMHz, float stopMHz);

protected:

  void paintEvent(QPaintEvent *event) override;
  void mouseMoveEvent(QMouseEvent *event) override;
  void mouseReleaseEvent(QMouseEvent *event) override;
  void mousePressEvent(QMouseEvent *event) override;
  void leaveEvent(QEvent *) override;

private:

  QVector<double> freqData;   // X-axis in MHz
  QVector<double> powerData;  // Y-axis in dBm

  double startFreqMHz = 2000.0;
  double stopFreqMHz  = 10.0;

  int thresholdX;
  int totalsize = 0,count = 0;
  bool dragging;

  QPoint mousePos;
  bool mouseInside = false;

  QPainterPath path;
  QFile ocFile;
  QVector<QVector<double>> allFreqFrames;   // history
  QVector<QVector<double>> allPowerFrames;  // history

signals:

 void spectrumUpdated(const QVector<double> &power);
 void sendwaterfallstartstop(double startFreqMHz,double stopFreqMHz);
};

#endif /* SPECTRUMWIDGET_H */

