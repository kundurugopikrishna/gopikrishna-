#include "spectrumwidget.h"
#include "headers.h"
#include "qdir.h"
#include"waterfallwidget.h"
SpectrumWidget::SpectrumWidget(QWidget *parent)
    : QWidget(parent),
      thresholdX(40),
      dragging(false), //ocFile("C:/SpectrumLogs/spectrum_data.txt") //"/home/harish/Desktop/SpectrumLogs/spectrum_data.txt"
    ocFile("E:/180726_irsReceiver/spectrum_data.txt")
{
  setMouseTracking(true);

    /*QDir dir("C:/SpectrumLogs"); //"/home/harish/Desktop/SpectrumLogs"
    if (!dir.exists())
    {
        dir.mkpath(".");
    }

    if (!ocFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
    {
        qWarning() << "Cannot open file";
    }
    else
    {
        qDebug() << "open spectrum_data.text";
    }*/

 // connect(this,&SpectrumWidget::sendwaterfallstartstop,waterfall,&WaterfallWidget::setStartStopFreq);

}

QSize SpectrumWidget::sizeHint() const
{
  return QSize(400, 200);
}

void SpectrumWidget::setStartStop(float startMHz, float stopMHz)
{
  startFreqMHz = startMHz;
  stopFreqMHz  = stopMHz;

  qDebug()<<" Emitted : 1 ";
 // waterfallData->setStartStopFreq(startFreqMHz, stopFreqMHz);
   emit sendwaterfallstartstop(startFreqMHz,stopFreqMHz);
   qDebug()<<" Emitted : 2 ";

  update();
}


/*void SpectrumWidget::updateSpectrumData(const QVector<double> &freqMHz, const QVector<double> &powerdBm)
{

    qDebug()<<"hithere";
    // QTextStream out(&ocFile);

    // out << freqMHz.size() << ", " << powerdBm.size() << "\n";

    // for (int i = 0; i < freqMHz.size(); ++i)
    // {
    //     out << freqMHz[i] << ", " ;
    // }
    // out << "\n";
    // for (int i = 0; i < powerdBm.size(); ++i)
    // {
    //     out << powerdBm[i] << ", ";
    // }
    // out << "\n";

    for(int i = 0; i< freqMHz.count(); i++)
    {

        if(freqMHz.at(i) < startFreqMHz)
        {
            startFreqMHz = freqMHz.at(i);
        }
        if(freqMHz.at(i) > stopFreqMHz)
        {
            stopFreqMHz = freqMHz.at(i);
        }
    }
    if(count == 0)
    {
     freqData = freqMHz;
     powerData =  powerdBm;
     count++;
    }

    else
    {
        for(int i=0;i<freqMHz.count();i++)
        {
            if(freqData.indexOf(freqMHz.at(i)) == -1)
            {
              freqData.append(freqMHz.at(i));
            }
            if(powerData.indexOf(freqMHz.at(i)) == -1)
            {
              powerData.append(powerdBm.at(i));
            }
        }
    }
   update();
}
*/


void SpectrumWidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    // Find overall start and stop frequency
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < startFreqMHz)
            startFreqMHz = freqMHz[i];

        if (freqMHz[i] > stopFreqMHz)
            stopFreqMHz = freqMHz[i];
    }

    // First packet
    if (count == 0)
    {
        freqData = freqMHz;
        powerData = powerdBm;
        count++;
    }
    else
    {
        // Update existing values or append new frequencies
        for (int i = 0; i < freqMHz.size(); i++)
        {
            int index = freqData.indexOf(freqMHz[i]);

            if (index >= 0)
            {
                // Frequency already exists
                // Replace old power with new power
                powerData[index] = powerdBm[i];
            }
            else
            {
                // New frequency
                freqData.append(freqMHz[i]);
                powerData.append(powerdBm[i]);
            }
        }
    }

    update();
}


void SpectrumWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.fillRect(rect(), Qt::black);
    painter.setRenderHint(QPainter::Antialiasing);

    const int w = width();
    const int h = height();

    // --------------------------------------------
    // 1. Bottom Start / Stop Labels
    // --------------------------------------------
    painter.setPen(Qt::yellow);
    QFont font = painter.font();
    font.setBold(true);
    font.setPointSize(10);
    painter.setFont(font);

    painter.drawText(5, h - 5,
                     QString("%1").arg(startFreqMHz, 0, 'f', 2));
    painter.drawText(w - 60, h - 5,
                     QString("%1").arg(stopFreqMHz, 0, 'f', 2));

    // --------------------------------------------
    // 2. Bottom axis title
    // --------------------------------------------
    painter.setPen(Qt::white);
    QFont bottomFont = painter.font();
    bottomFont.setPointSize(9);
    bottomFont.setBold(true);
    painter.setFont(bottomFont);

    QString bottomLabel = "Frequency in MHz";
    QFontMetrics fm(painter.font());
    int textWidth = fm.horizontalAdvance(bottomLabel);
    int centerX = (w - textWidth) / 2;

    painter.drawText(centerX, h - 5, bottomLabel);

    // --------------------------------------------
    // 3. Plot Rectangle
    // --------------------------------------------
    const int leftMargin = 40;
    const int rightMargin = 10;
    const int topMargin = 55;
    const int bottomMargin = 25;

    QRectF plotRect(leftMargin, topMargin,
                    w - leftMargin - rightMargin,
                    h - topMargin - bottomMargin);

    // --------------------------------------------
    // 4. Grid Background
    // --------------------------------------------
    painter.setPen(QPen(QColor(60, 60, 60), 1));
    int gridXStep = 50;
    int gridYStep = 25;

    for (int x = plotRect.left(); x < plotRect.right(); x += gridXStep)
        painter.drawLine(x, plotRect.top(), x, plotRect.bottom());

    for (int y = plotRect.top(); y < plotRect.bottom(); y += gridYStep)
        painter.drawLine(plotRect.left(), y, plotRect.right(), y);

    // --------------------------------------------
    // 5. Y-Axis (Fixed scale: -12 to -132 dBm)
    // --------------------------------------------
    painter.setPen(Qt::white);
    QFont smallFont = painter.font();
    smallFont.setPointSize(8);
    painter.setFont(smallFont);

    int divisions = 10;
    int yStep = plotRect.height() / divisions;

    for (int i = 0; i <= divisions; ++i)
    {
        int y = plotRect.top() + i * yStep;
        int value = -12 * (i + 1);        // -12, -24, ..., -132

        painter.drawText(leftMargin - 35, y + 4, QString::number(value));
        painter.drawLine(plotRect.left(), y, plotRect.right(), y);
    }


    // --------------------------------------------
    // 6. Spectrum Line
    // --------------------------------------------
    if (!freqData.isEmpty() && !powerData.isEmpty())
    {
        QPainterPath path;

        double minF = startFreqMHz;//*/freqData.first();
        double maxF = stopFreqMHz;//*/freqData.last();

        // Fixed Y axis
        double minY = -132;
        double maxY = -12;

        auto toPixelX = [&](double f)
        {
            return plotRect.left() +
                   (f - minF) / (maxF - minF) * plotRect.width();
        };

        auto toPixelY = [&](double p)
        {
            return plotRect.bottom() -
                   (p - minY) / (maxY - minY) * plotRect.height();
        };

        path.moveTo(toPixelX(freqData[0]), toPixelY(powerData[0]));
        for (int i = 1; i < freqData.size(); ++i)
        {
            path.lineTo(toPixelX(freqData[i]), toPixelY(powerData[i]));
        }

        painter.setPen(QPen(Qt::green, 2));
        painter.drawPath(path);
    }

    // --------------------------------------------
    // 7. Graph Title
    // --------------------------------------------
    painter.setPen(QColor("#FF1493"));
    painter.setFont(smallFont);
    painter.drawText(plotRect.left() - 30,
                     topMargin - 10,
                     "Frequency vs Amplitude");

    // --------------------------------------------
    // 8. Threshold Vertical Line
    // --------------------------------------------
    painter.setPen(QPen(Qt::yellow, 2));
    painter.drawLine(thresholdX, plotRect.top(), thresholdX, plotRect.bottom());
    painter.drawText(thresholdX + 5, plotRect.top() + 15, "TH");

    // --------------------------------------------
    // 9. Mouse Tracking (Frequency + Power Display)
    // --------------------------------------------
    if (mouseInside && !freqData.isEmpty())
    {
        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(mousePos.x(), plotRect.top(),
                         mousePos.x(), plotRect.bottom());
        painter.drawLine(plotRect.left(), mousePos.y(),
                         plotRect.right(), mousePos.y());

        double minF = startFreqMHz;//freqData.first();
        double maxF = stopFreqMHz;//freqData.last();

        double ratio = double(mousePos.x() - plotRect.left()) / plotRect.width();
        ratio = qBound(0.0, ratio, 1.0);

        double mouseFreq = minF + ratio * (maxF - minF);

        int index = qBound(0,
                           int(ratio * freqData.size()),
                           freqData.size());

        double mousePower = powerData[index];

        painter.setPen(Qt::yellow);
        painter.drawText(plotRect.left() + 120,
                         plotRect.top() - 8,
                         QString("Freq: %1 MHz   Power: %2 dBm")
                             .arg(mouseFreq, 0, 'f', 3)
                             .arg(mousePower, 0, 'f', 1));
    }
}

void SpectrumWidget::mousePressEvent(QMouseEvent *event)
{
    dragging = true;
     if (qAbs(event->pos().x() - thresholdX) <= 5)
         dragging = true;
}

void SpectrumWidget::mouseMoveEvent(QMouseEvent *event)
{
   if (dragging)
   {
      thresholdX = qBound(40, event->pos().x(), width() - 10);
      update();
    }
     mousePos = event->pos();
     mouseInside = true;
     update();
}
void SpectrumWidget::leaveEvent(QEvent *)
{
  mouseInside = false;
  update();
}

void SpectrumWidget::mouseReleaseEvent(QMouseEvent *event)
{
  Q_UNUSED(event);
  dragging = false;
 }

