#include "spectrumwaterfallwidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QColor>
#include <algorithm>

SpectrumWaterfallWidget::SpectrumWaterfallWidget(QWidget *parent)
    : QWidget(parent), maxHistory(100) {}

void SpectrumWaterfallWidget::addSpectrum(const QVector<int> &data) {
    currentSpectrum = data;
    spectrumHistory.enqueue(data);

    if (spectrumHistory.size() > maxHistory) {
        spectrumHistory.dequeue();
    }
    update();
}

void SpectrumWaterfallWidget::clearHistory() {
    spectrumHistory.clear();
    update();
}

QColor SpectrumWaterfallWidget::mapColor(int intensity) const {
    if (intensity < 0) intensity = 0;
    if (intensity > 100) intensity = 100;

    int hue = 240 - (intensity * 240 / 100);
    return QColor::fromHsv(hue, 255, 255);
}

void SpectrumWaterfallWidget::paintEvent(QPaintEvent *) {
    // QPainter painter(this);
    // painter.fillRect(rect(), Qt::black);

    // int w = width();
    // int h = height();
    // int spectrumHeight = h / 2;
    // int waterfallHeight = h - spectrumHeight;

    // // === Spectrum (Top) ===
    // painter.save();
    // painter.setPen(QPen(Qt::green, 2));

    // if (!currentSpectrum.isEmpty()) {
    //     int xStep = (w - 60) / (currentSpectrum.size() - 1);
    //     QPainterPath path;
    //     path.moveTo(30, spectrumHeight - 10 - currentSpectrum[0]);

    //     for (int i = 1; i < currentSpectrum.size(); ++i) {
    //         int x = 30 + i * xStep;
    //         int y = spectrumHeight - 10 - currentSpectrum[i];
    //         path.lineTo(x, y);
    //     }
    //     painter.drawPath(path);
    // }

    // // Spectrum Y-axis
    // painter.setPen(Qt::white);
    // int yStep = (spectrumHeight - 40) / 5;
    // for (int i = 0; i <= 5; ++i) {
    //     int y = spectrumHeight - 10 - i * yStep;
    //     int value = i * 20;
    //     painter.drawText(5, y + 5, QString::number(value));
    //     painter.drawLine(30, y, w - 10, y);
    // }

    // // Spectrum X-axis
    // if (!currentSpectrum.isEmpty()) {
    //     int xStep = (w - 60) / (currentSpectrum.size() - 1);
    //     int baseFreq = 470; // MHz
    //     int stepFreq = 5;
    //     for (int i = 0; i < currentSpectrum.size(); ++i) {
    //         int x = 30 + i * xStep;
    //         if (i % 10 == 0) {
    //             painter.drawText(x, spectrumHeight - 5, QString::number(baseFreq + i * stepFreq));
    //         }
    //     }
    //     painter.drawText(w / 2, spectrumHeight, "Frequency (MHz)");
    // }
    // painter.restore();

    // // === Waterfall (Bottom) ===
    //     painter.save();

    //     int offsetY = spectrumHeight;
    //     int rowHeight = std::max(1, waterfallHeight / maxHistory);

    //     // Determine how many rows fit in the view
    //     int rowsToShow = waterfallHeight / rowHeight;
    //     int startRow = std::max(0, spectrumHistory.size() - rowsToShow);

    //     // Get the visible part of the history
    //     QList<QVector<int>> visibleHistory = spectrumHistory.mid(startRow);

    //     int row = 0;
    //     foreach (const QVector<int> &spectrum, visibleHistory) {
    //         if (spectrum.isEmpty()) continue;
    //         if (spectrum.size() < 2) continue;

    //         int xStep = (w - 60) / (spectrum.size() - 1);

    //         for (int i = 0; i < spectrum.size(); ++i) {
    //             int x = 30 + i * xStep;
    //             // Always sky blue, ignore intensity
    //             QColor color(135, 206, 250);  // SkyBlue
    //             painter.fillRect(x, offsetY + row * rowHeight,
    //                              xStep, rowHeight, color);
    //         }
    //         row++;
    //     }

    //     painter.restore();
    }
