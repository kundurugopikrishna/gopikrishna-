#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"spectrumwidget.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    udpSocket = new QUdpSocket(this);
    spectrum = new Spectrumwidget(this);
    waterfall=new Waterfallwidget(this);
  //  spectrum->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    spectrum->setMinimumSize(400, 200);
    ui->verticalLayout->addWidget(spectrum, 1);

    ui->verticalLayout_2->addWidget(waterfall,1);
    //connect(receiver,&UdpReceiver::spectrumReceived,this,&MainWindow::updateSpect);
    tcpSocket = new QTcpSocket(this);

    tcpSocket->connectToHost("192.168.1.3", 5001);

    if(tcpSocket->waitForConnected(10000))
    {
        qDebug() << "TCP Connected Listening to TCP port";
    }
    else
    {
        qDebug() << "Connection Failed";
    }

    bool ok = udpSocket->bind(QHostAddress::AnyIPv4,
                              7001,
                              QUdpSocket::ShareAddress);

    if(!ok)
    {
        qDebug() << "UDP Bind Failed";
        return;
    }

    qDebug() << "UDP Listening on Port 7001";

    connect(udpSocket,&QUdpSocket::readyRead, this,&MainWindow::readPendingDatagrams);

    /*connect(ui->lineEdit,&QLineEdit::editingFinished, this,&MainWindow::on_pushButton_clicked);

    connect(ui->lineEdit_2, &QLineEdit::editingFinished,this,&MainWindow::on_pushButton_clicked);*/
    connect(this,&MainWindow::spectrumDataReady,spectrum, &Spectrumwidget::updateSpectrumData,Qt::QueuedConnection);
   // connect(this,&MainWindow::spectrumDataReady,spectrum,&Spectrumwidget::updateSpectrumData);
  //  connect(this,&MainWindow::waterfallDataReady,waterfall,&Waterfallwidget::powerUpdate,Qt::QueuedConnection);

    connect(spectrum, &Spectrumwidget::spectrumRowReady,
            waterfall, &Waterfallwidget::addWaterfallRow);
    connect(spectrum, &Spectrumwidget::startStopChanged,
            waterfall, &Waterfallwidget::setstartstopwaterfall);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString startStr = ui->lineEdit->text();
    QString stopStr  = ui->lineEdit_2->text();

    // Update SpectrumWidget
    spectrum->setStartStop(startStr.toInt(), stopStr.toInt());

    qDebug() << "Start =" << startStr << "Stop =" << stopStr;

    // Send command over TCP
    QString cmd = QString("START:%1;STOP:%2")
                      .arg(startStr)
                      .arg(stopStr);

    tcpSocket->write(cmd.toUtf8());
    tcpSocket->flush();



}

void MainWindow::readPendingDatagrams()

{

  //  qDebug()<<"data connected";
        while (udpSocket->hasPendingDatagrams())
        {
            QByteArray datagram;
            datagram.resize(udpSocket->pendingDatagramSize());

            QHostAddress sender;
            quint16 senderPort;

            udpSocket->readDatagram(datagram.data(),
                                    datagram.size(),
                                    &sender,
                                    &senderPort);

            QDataStream stream(datagram);
            stream.setByteOrder(QDataStream::BigEndian);

            //-------------------------
            // Header
            //-------------------------
            quint16 header;
            stream >> header;

            if (header != 0x8765)
            {
                qDebug() << "Invalid Header";
                continue;
            }

            //-------------------------
            // FFT Point Count
            //-------------------------
            quint16 fftPoints;
            stream >> fftPoints;

            QVector<double> freq;
            QVector<double> power;

            freq.reserve(fftPoints);
            power.reserve(fftPoints);

            //-------------------------
            // Read FFT Data
            //-------------------------
            for (int i = 0; i < fftPoints; i++)
            {
                quint32 raw;

                // Frequency
                stream >> raw;
                float f;
                memcpy(&f, &raw, sizeof(float));

                // Power
                stream >> raw;
                float p;
                memcpy(&p, &raw, sizeof(float));

                // Noise
                stream >> raw;
                float n;
                memcpy(&n, &raw, sizeof(float));

                Q_UNUSED(n);

                freq.append(f / 1000.0);   // Convert kHz to MHz
                power.append(p);
            }

            //-------------------------
            // Footer
            //-------------------------
            quint16 footer;
            stream >> footer;

            if (footer != 0x4321)
            {
                qDebug() << "Invalid Footer";
                continue;
            }

           /* qDebug() << "--------------------------------";
            qDebug() << "Valid UDP Packet";
            qDebug() << "Points :" << fftPoints;
            qDebug() << "Start  :" << freq.first();
            qDebug() << "Stop   :" << freq.last();
            qDebug() << "--------------------------------";*/

            // Pass the complete FFT data
        /*  static qint64 lastUpdate = 0;
            qint64 now = QDateTime::currentMSecsSinceEpoch();
          //  qDebug() << QDateTime::fromMSecsSinceEpoch(now).toString("yyyy-MM-dd hh:mm:ss.zzz");

            if (now - lastUpdate >50)
            {
                emit spectrumDataReady(freq, power);
                lastUpdate =now;
            }*/

           emit spectrumDataReady(freq, power);
          //  emit waterfallDataReady(power);
           // spectrumDataReady(freq, power);
















        }
}

void MainWindow::updateSpectrum(const QVector<double> &freq, const QVector<double> &power)
{
    qDebug()<<"hi";
}


