#ifndef SPECTRUMWIDGET_H
#define SPECTRUMWIDGET_H

#include <QWidget>
#include <QPainter>
#include <QPainterPath>
#include <QPen>
#include <QColor>
#include <QPaintEvent>
#include <QFont>
#include <QBrush>
#include <QtMath>
#include <QTimer>   // add this
#include <algorithm>
#include"waterfallwidget.h"
class Spectrumwidget : public QWidget
{
    Q_OBJECT
public:
    explicit Spectrumwidget(QWidget *parent = nullptr);

    void setStartStop(int startMHz, int stopMHz);

private slots:

  // int freqToPixelX(double freqMHz) const;
    //void resizeEvent(QResizeEvent *event);

public:
    void updateSpectrumData(const QVector<double> &freqMHz, const QVector<double> &powerdBm);

private:
    float startFreqMHz = 20;
    float stopFreqMHz = 6000;

    QVector<double> freqData;
    QVector<double> powerData;
    QHash<double, int> freqIndexMap;   // <-- NEW: maps frequency -> index in freqData/powerData

    double lastStartFreqMHz = -1;   // sentinel: -1 means "no data yet"
    double lastStopFreqMHz  = -1;
    int count = 0;

    int expectedPackets = 0;
    int receivedPackets = 0;

    bool dataDirty = false;
    QVector<int> changedIndices;   // which indices changed since last paint
    QTimer *refreshTimer;

    Waterfallwidget *waterfall;

protected:
    void paintEvent(QPaintEvent *)override;
signals:
    void startStopChanged(double startMHz, double stopMHz);
    void spectrumRowReady(double startMHz, double stopMHz, const QVector<double> &powerdBm);

};

#endif // SPECTRUMWIDGET_H
