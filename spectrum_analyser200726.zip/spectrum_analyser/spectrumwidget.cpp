#include "spectrumwidget.h"
#include <QTimer>
#include<waterfallwidget.h>
Spectrumwidget::Spectrumwidget(QWidget *parent)
    : QWidget{parent}


{


    refreshTimer = new QTimer(this);
    refreshTimer->setInterval(10);

    connect(refreshTimer, &QTimer::timeout, this, [this]()
            {
                if (dataDirty)
                {
                    update();          // Request a repaint
                    dataDirty = false;
                }
            });

    refreshTimer->start();
 //   connect(this,&Spectrumwidget::startStopChanged,waterfall,&Waterfallwidget::setstartstopwaterfall);
}
/*void Spectrumwidget::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    // recompute any cached layout here if you have it
    dataDirty = true;   // force a repaint at the new size
    update();
}*/
//version 0
/*void Spectrumwidget::setStartStop(int startMHz, int stopMHz)
{
    startFreqMHz = startMHz;
    stopFreqMHz  = stopMHz;

    freqData.clear();
    powerData.clear();
    count = 0;
    update();
}
*/
//version 1

/*void Spectrumwidget::setStartStop(int startMHz, int stopMHz)
{
    startFreqMHz = startMHz;
    stopFreqMHz  = stopMHz;

    freqData.clear();
    powerData.clear();
    changedIndices.clear();    // must clear, prevents stale-index crash
    count = 0;

    lastStartFreqMHz = startFreqMHz;
    lastStopFreqMHz  = stopFreqMHz;

    dataDirty = true;   // let the 30fps timer repaint, not update() directly

    emit startStopChanged(startFreqMHz, stopFreqMHz);   // notify waterfall/others
}*/



void Spectrumwidget::setStartStop(int startMHz, int stopMHz)
{
    startFreqMHz = startMHz;
    stopFreqMHz  = stopMHz;

    lastStartFreqMHz = startFreqMHz;
    lastStopFreqMHz  = stopFreqMHz;

    // Number of 20 MHz packets
    expectedPackets = qCeil((stopFreqMHz - startFreqMHz) / 20.0);




   /* double packetStartFreq = freqMHz.first();

    int packetNumber = qRound((packetStartFreq - startFreqMHz) / 20.0);

    qDebug() << packetStartFreq << packetNumber;*/

    // Total FFT points
    int totalPoints = expectedPackets * 1280;

    freqData.resize(totalPoints);
    powerData.resize(totalPoints);

    std::fill(powerData.begin(), powerData.end(), -127.0);

    receivedPackets = 0;
    changedIndices.clear();
    dataDirty = false;

    emit startStopChanged(startFreqMHz, stopFreqMHz);   // <-- ADD HERE, at the end


}







































// int Spectrumwidget::freqToPixelX(double freqMHz) const
// {
//     if (stopFreqMHz <= startFreqMHz)
//         return 0;
//     double ratio = (freqMHz - startFreqMHz) / (stopFreqMHz - startFreqMHz);
//     return static_cast<int>(ratio * width());

// }


/*void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    // Find overall start and stop frequency
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < startFreqMHz)
            startFreqMHz = freqMHz[i];

        if (freqMHz[i] > stopFreqMHz)
            stopFreqMHz = freqMHz[i];
    }

    // First packet
    if (count == 0)
    {
        freqData = freqMHz;
        powerData = powerdBm;
        count++;
    }
    else
    {
        // Update existing values or append new frequencies
        for (int i = 0; i < freqMHz.size(); i++)
        {
            int index = freqData.indexOf(freqMHz[i]);

            if (index >= 0)
            {
                // Frequency already exists
                // Replace old power with new power
                powerData[index] = powerdBm[i];
            }
            else
            {
                // New frequency
                freqData.append(freqMHz[i]);
                powerData.append(powerdBm[i]);
            }
        }
    }

    update();
}*/


//version two
/*void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    // Find this packet's own start/stop (its actual sub-band range)
    double packetStart = freqMHz.first();
    double packetStop  = freqMHz.last();
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < packetStart) packetStart = freqMHz[i];
        if (freqMHz[i] > packetStop)  packetStop  = freqMHz[i];
    }

    // --- NEW: detect a fresh scan (new overall start/stop) and clear old data ---
    // Adjust this condition to whatever actually signals "new scan" for you —
    // e.g. if you already call setStartStopFreq() with the new range before
    // this function runs, compare against that instead of packetStart/Stop.
    if (lastStartFreqMHz >= 0 &&
        (!qFuzzyCompare(lastStartFreqMHz, startFreqMHz) ||
         !qFuzzyCompare(lastStopFreqMHz, stopFreqMHz)))
    {
        freqData.clear();
        powerData.clear();
        count = 0;
    }

    lastStartFreqMHz = startFreqMHz;
    lastStopFreqMHz  = stopFreqMHz;

    // Find overall start and stop frequency
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < startFreqMHz)
            startFreqMHz = freqMHz[i];
        if (freqMHz[i] > stopFreqMHz)
            stopFreqMHz = freqMHz[i];
    }

    // First packet
    if (count == 0)
    {
        freqData = freqMHz;
        powerData = powerdBm;
        count++;
    }
    else
    {
        // Update existing values or append new frequencies
        for (int i = 0; i < freqMHz.size(); i++)
        {
            int index = freqData.indexOf(freqMHz[i]);
            if (index >= 0)
            {
                powerData[index] = powerdBm[i];
            }
            else
            {
                freqData.append(freqMHz[i]);
                powerData.append(powerdBm[i]);
            }
        }
    }
    update();
}
*/

//version three
/*
void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    // Find this packet's own start/stop (its actual sub-band range)
    double packetStart = freqMHz.first();
    double packetStop  = freqMHz.last();
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < packetStart) packetStart = freqMHz[i];
        if (freqMHz[i] > packetStop)  packetStop  = freqMHz[i];
    }

    // --- detect a fresh scan and clear old data ---
    if (lastStartFreqMHz >= 0 &&
        (!qFuzzyCompare(lastStartFreqMHz, startFreqMHz) ||
         !qFuzzyCompare(lastStopFreqMHz, stopFreqMHz)))
    {
        freqData.clear();
        powerData.clear();
        freqIndexMap.clear();   // <-- NEW: keep the map in sync with freqData
        count = 0;
    }
    lastStartFreqMHz = startFreqMHz;
    lastStopFreqMHz  = stopFreqMHz;

    // Find overall start and stop frequency
    for (int i = 0; i < freqMHz.size(); i++)
    {
        if (freqMHz[i] < startFreqMHz)
            startFreqMHz = freqMHz[i];
        if (freqMHz[i] > stopFreqMHz)
            stopFreqMHz = freqMHz[i];
    }

    // First packet
    if (count == 0)
    {
        freqData = freqMHz;
        powerData = powerdBm;

        freqIndexMap.clear();
        freqIndexMap.reserve(freqData.size());
        for (int i = 0; i < freqData.size(); i++)
            freqIndexMap.insert(freqData[i], i);

        count++;
    }
    else
    {
        // Update existing values or append new frequencies — O(1) per lookup now
        for (int i = 0; i < freqMHz.size(); i++)
        {
            auto it = freqIndexMap.constFind(freqMHz[i]);
            if (it != freqIndexMap.constEnd())
            {
                powerData[it.value()] = powerdBm[i];
            }
            else
            {
                int newIndex = freqData.size();
                freqData.append(freqMHz[i]);
                powerData.append(powerdBm[i]);
                freqIndexMap.insert(freqMHz[i], newIndex);
            }
        }
    }

    update();
}
*/
//version four

/*void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    constexpr double kPowerEpsilon = -3;
    constexpr int    kChunkSize    = 20;   // known packet size from your hardware

    // --- Detect a fresh scan (range changed) -> reset everything ---
    if (lastStartFreqMHz >= 0 &&
        (!qFuzzyCompare(lastStartFreqMHz, startFreqMHz) ||
         !qFuzzyCompare(lastStopFreqMHz, stopFreqMHz)))
    {
        freqData.clear();
        powerData.clear();
        freqIndexMap.clear();
        changedIndices.clear();
        count = 0;
        dataDirty = true;

        // Pre-reserve space for the expected full sweep, since we know
        // chunks arrive in fixed sizes of kChunkSize.
        int expectedPoints = static_cast<int>((stopFreqMHz - startFreqMHz) / 0.015625) + kChunkSize;
        if (expectedPoints > 0)
        {
            freqData.reserve(expectedPoints);
            powerData.reserve(expectedPoints);
            freqIndexMap.reserve(expectedPoints);
        }
    }
    lastStartFreqMHz = startFreqMHz;
    lastStopFreqMHz  = stopFreqMHz;

    // --- Process each point in this chunk ---
    for (int i = 0; i < freqMHz.size(); i++)
    {
        double f = freqMHz[i];
        double p = powerdBm[i];

        // 1. Range check — only accept points inside the requested start/stop window.
        //    Anything outside is discarded (protects against garbage/out-of-range data).
        if (f < startFreqMHz || f > stopFreqMHz)
            continue;

        // 2. Look up whether we've already seen this frequency bin.
        auto it = freqIndexMap.constFind(f);
        if (it != freqIndexMap.constEnd())
        {
            // Already have this point — replace only if the power actually changed.
            int idx = it.value();
            if (std::abs(powerData[idx] - p) > kPowerEpsilon)
            {
                powerData[idx] = p;       // remove/overwrite old value with new one
                dataDirty = true;
                changedIndices.append(idx);
            }
        }
        else
        {
            // New frequency bin within range — add it (this is how the
            // sweep fills in progressively across sub-band packets).
            int newIndex = freqData.size();
            freqData.append(f);
            powerData.append(p);
            freqIndexMap.insert(f, newIndex);
            dataDirty = true;
            changedIndices.append(newIndex);
        }
    }

    if (count == 0 && !freqData.isEmpty())
        count++;   // mark that we've received at least one valid chunk
}*/
// spectrumwidget.cpp


//version 7

void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    constexpr int PacketPoints = 1280;
    constexpr double PacketSpanMHz = 20.0;
    constexpr double PowerThreshold = 10.0;

    // First packet initializes the buffers (normally already done by setStartStop,
    // this is just a safety fallback)
    if (freqData.isEmpty())
    {
        freqData.resize(expectedPackets * PacketPoints);
        powerData.resize(expectedPackets * PacketPoints);
        std::fill(powerData.begin(), powerData.end(), -127.0);
    }

    // Which 20 MHz sub-band packet is this?
    double packetStartFreq = freqMHz.first();
    int packetNumber = qRound((packetStartFreq - startFreqMHz) / PacketSpanMHz);
    if (packetNumber < 0 || packetNumber >= expectedPackets)
        return;

    int startIndex = packetNumber * PacketPoints;
    bool changed = false;

    for (int i = 0; i < PacketPoints && i < powerdBm.size(); i++)
    {
        int index = startIndex + i;

        freqData[index] = freqMHz[i];   // frequency is fixed, just store it

        // Only replace power if it's meaningfully different from before —
        // this IS "add the power point if it is different from old data"
        if (std::abs(powerData[index] - powerdBm[i]) >= PowerThreshold)
        {
            powerData[index] = powerdBm[i];
            changed = true;
        }
    }

    if (changed)
    {
        dataDirty = true;
        emit spectrumRowReady(startFreqMHz, stopFreqMHz, powerData);
    }
}




// void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
//                                         const QVector<double> &powerdBm)
// {
//     if (freqMHz.isEmpty() || powerdBm.isEmpty())
//         return;




//     // New UDP packet arrives
//     receiveBufferFreq.append(freqMHz);
//     receiveBufferPower.append(powerdBm);

//     // Search for requested range
//     int startIndex = -1;
//     int stopIndex  = -1;

//     for (int i = 0; i < receiveBufferFreq.size(); i++)
//     {
//         if (qFuzzyCompare(receiveBufferFreq[i] + 1.0, startFreqMHz + 1.0))
//         {
//             startIndex = i;
//             break;
//         }
//     }

//     if (startIndex >= 0)
//     {
//         for (int i = startIndex; i < receiveBufferFreq.size(); i++)
//         {
//             if (qFuzzyCompare(receiveBufferFreq[i] + 1.0, stopFreqMHz + 1.0))
//             {
//                 stopIndex = i;
//                 break;
//             }
//         }
//     }

//     if (startIndex >= 0 && stopIndex >= 0)
//     {
//         // Complete range found
//         freqData  = receiveBufferFreq.mid(startIndex,
//                                          stopIndex - startIndex + 1);

//         powerData = receiveBufferPower.mid(startIndex,
//                                            stopIndex - startIndex + 1);

//         emit spectrumRowReady(startFreqMHz, stopFreqMHz, powerData);

//         update();

//         // Remove processed data

//        // freqData.clear();
//        // powerData.clear();

//     }

// }



































/*void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz, const QVector<double> &powerdBm)
{
    // QTextStream out(&ocFile);

    // out << freqMHz.size() << ", " << powerdBm.size() << "\n";

    // for (int i = 0; i < freqMHz.size(); ++i)
    // {
    //     out << freqMHz[i] << ", " ;
    // }
    // out << "\n";
    // for (int i = 0; i < powerdBm.size(); ++i)
    // {
    //     out << powerdBm[i] << ", ";
    // }
    // out << "\n";

    for(int i = 0; i< freqMHz.count(); i++)
    {

        if(freqMHz.at(i) < startFreqMHz)
        {
            startFreqMHz = freqMHz.at(i);
        }
        if(freqMHz.at(i) > stopFreqMHz)
        {
            stopFreqMHz = freqMHz.at(i);
        }
    }
    if(count == 0)
    {
        freqData = freqMHz;
        powerData =  powerdBm;
        count++;
    }

    else
    {
        for(int i=0;i<freqMHz.count();i++)
        {
            if(freqData.indexOf(freqMHz.at(i)) == -1)
            {
                freqData.append(freqMHz.at(i));
            }
            if(powerData.indexOf(freqMHz.at(i)) == -1)
            {
                powerData.append(powerdBm.at(i));
            }
        }
    }
    update();
}

*/

/*void Spectrumwidget::updateSpectrumData(const QVector<double> &freqMHz,
                                        const QVector<double> &powerdBm)
{
    if (freqMHz.isEmpty() || powerdBm.isEmpty())
        return;

    constexpr int PacketPoints = 1280;
    constexpr double PacketSpanMHz = 20.0;
    constexpr double PowerThreshold = 3.0;

    // Packet start frequency
    double packetStartFreq = freqMHz.first();

    // Which 20 MHz block is this?
    int packetNumber = qRound((packetStartFreq - startFreqMHz) / PacketSpanMHz);

    // Starting index in the full spectrum
    int startIndex = packetNumber * PacketPoints;

    if (startIndex < 0)
        return;

    if (startIndex + PacketPoints > powerData.size())
        return;

    changedIndices.clear();

    for (int i = 0; i < PacketPoints && i < powerdBm.size(); i++)
    {
        int index = startIndex + i;

        if (std::abs(powerData[index] - powerdBm[i]) >= PowerThreshold)
        {
            powerData[index] = powerdBm[i];
            changedIndices.append(index);
        }
    }

    if (!changedIndices.isEmpty())
        dataDirty = true;
}*/
void Spectrumwidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.fillRect(rect(), Qt::black);
    painter.setRenderHint(QPainter::Antialiasing);

    const int w = width();
    const int h = height();

    // --------------------------------------------
    // 1. Bottom Start / Stop Labels
    // --------------------------------------------
    painter.setPen(Qt::yellow);
    QFont font = painter.font();
    font.setBold(true);
    font.setPointSize(10);
    painter.setFont(font);

    painter.drawText(5, h - 5,
                     QString("%1").arg(startFreqMHz, 0, 'f', 2));
    painter.drawText(w - 60, h - 5,
                     QString("%1").arg(stopFreqMHz, 0, 'f', 2));

    // --------------------------------------------
    // 2. Bottom axis title
    // --------------------------------------------
    painter.setPen(Qt::white);
    QFont bottomFont = painter.font();
    bottomFont.setPointSize(9);
    bottomFont.setBold(true);
    painter.setFont(bottomFont);

    QString bottomLabel = "Frequency in MHz";
    QFontMetrics fm(painter.font());
    int textWidth = fm.horizontalAdvance(bottomLabel);
    int centerX = (w - textWidth) / 2;

    painter.drawText(centerX, h - 5, bottomLabel);

    // --------------------------------------------
    // 3. Plot Rectangle
    // --------------------------------------------
    const int leftMargin = 40;
    const int rightMargin = 10;
    const int topMargin = 55;
    const int bottomMargin = 25;

    QRectF plotRect(leftMargin, topMargin,
                    w - leftMargin - rightMargin,
                    h - topMargin - bottomMargin);

    // --------------------------------------------
    // 4. Grid Background
    // --------------------------------------------
    painter.setPen(QPen(QColor(60, 60, 60), 1));
    int gridXStep = 50;
    int gridYStep = 25;

    for (int x = plotRect.left(); x < plotRect.right(); x += gridXStep)
        painter.drawLine(x, plotRect.top(), x, plotRect.bottom());

    for (int y = plotRect.top(); y < plotRect.bottom(); y += gridYStep)
        painter.drawLine(plotRect.left(), y, plotRect.right(), y);

    // --------------------------------------------
    // 5. Y-Axis (Fixed scale: -12 to -132 dBm)
    // --------------------------------------------
    painter.setPen(Qt::white);
    QFont smallFont = painter.font();
    smallFont.setPointSize(8);
    painter.setFont(smallFont);

    int divisions = 10;
    int yStep = plotRect.height() / divisions;

    for (int i = 0; i <= divisions; ++i)
    {
        int y = plotRect.top() + i * yStep;
        int value = -12 * (i + 1);        // -12, -24, ..., -132

        painter.drawText(leftMargin - 35, y + 4, QString::number(value));
        painter.drawLine(plotRect.left(), y, plotRect.right(), y);
    }


    // --------------------------------------------
    // 6. Spectrum Line
    // --------------------------------------------
    // if (!freqData.isEmpty() && !powerData.isEmpty())
    // {
    //     QPainterPath path;

    //     double minF = startFreqMHz;//*/freqData.first();
    //     double maxF = stopFreqMHz;//*/freqData.last();

    //     // Fixed Y axis
    //     double minY = -132;
    //     double maxY = -12;

    //     auto toPixelX = [&](double f)
    //     {
    //         return plotRect.left() +
    //                (f - minF) / (maxF - minF) * plotRect.width();
    //     };

    //     auto toPixelY = [&](double p)
    //     {
    //         return plotRect.bottom() -
    //                (p - minY) / (maxY - minY) * plotRect.height();
    //     };

    //     path.moveTo(toPixelX(freqData[0]), toPixelY(powerData[0]));
    //     for (int i = 1; i < freqData.size(); ++i)
    //     {
    //         path.lineTo(toPixelX(freqData[i]), toPixelY(powerData[i]));
    //     }

    //     painter.setPen(QPen(Qt::green, 2));
    //     painter.drawPath(path);
    // }




    // --------------------------------------------
    // 6. Spectrum Line
    // --------------------------------------------
    if (!powerData.isEmpty())
    {
        QPainterPath path;

        const double minY = -132.0;
        const double maxY = -12.0;

        int totalPoints = powerData.size();

        auto toPixelX = [&](int index)
        {
            return plotRect.left() +
                   (double(index) / (totalPoints - 1)) * plotRect.width();
        };

        auto toPixelY = [&](double power)
        {
            return plotRect.bottom() -
                   ((power - minY) / (maxY - minY)) * plotRect.height();
        };

        path.moveTo(toPixelX(0), toPixelY(powerData[0]));

        for (int i = 1; i < totalPoints; i++)
        {
            path.lineTo(toPixelX(i), toPixelY(powerData[i]));
        }

        painter.setPen(QPen(Qt::green, 2));
        painter.drawPath(path);
    }






































    // --------------------------------------------
    // 7. Graph Title
    // --------------------------------------------
    painter.setPen(QColor("#FF1493"));
    painter.setFont(smallFont);
    painter.drawText(plotRect.left() - 30,
                     topMargin - 10,
                     "Frequency vs Amplitude");
   /*
    // --------------------------------------------
    // 8. Threshold Vertical Line
    // --------------------------------------------
    painter.setPen(QPen(Qt::yellow, 2));
    painter.drawLine(thresholdX, plotRect.top(), thresholdX, plotRect.bottom());
    painter.drawText(thresholdX + 5, plotRect.top() + 15, "TH");*/

    // --------------------------------------------
    // 9. Mouse Tracking (Frequency + Power Display)
    // --------------------------------------------


   /* if (mouseInside && !freqData.isEmpty())
    {
        painter.setPen(QPen(Qt::white, 1));

        painter.drawLine(mousePos.x(), plotRect.top(),
                         mousePos.x(), plotRect.bottom());
        painter.drawLine(plotRect.left(), mousePos.y(),
                         plotRect.right(), mousePos.y());

        double minF = startFreqMHz;//freqData.first();
        double maxF = stopFreqMHz;//freqData.last();

        double ratio = double(mousePos.x() - plotRect.left()) / plotRect.width();
        ratio = qBound(0.0, ratio, 1.0);

        double mouseFreq = minF + ratio * (maxF - minF);

        int index = qBound(0,
                           int(ratio * freqData.size()),
                           freqData.size());

        double mousePower = powerData[index];

        painter.setPen(Qt::yellow);
        painter.drawText(plotRect.left() + 120,
                         plotRect.top() - 8,
                         QString("Freq: %1 MHz   Power: %2 dBm")
                             .arg(mouseFreq, 0, 'f', 3)
                             .arg(mousePower, 0, 'f', 1));
    }*/
}
