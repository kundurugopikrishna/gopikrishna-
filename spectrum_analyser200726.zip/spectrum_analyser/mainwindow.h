#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QUdpSocket>
#include <QVector>
#include "spectrumwidget.h"
#include <QWidget>
#include <QVector>
#include <QPainter>
#include <QPainterPath>
#include <QPen>
#include <QColor>
#include <QPaintEvent>
#include <QDateTime>
#include <cmath>
#include"waterfallwidget.h"
// spectrumwidget.h
#include <QTimer>   // add this
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
signals:
    void spectrumDataReady(const QVector<double> &freq,
                           const QVector<double> &power);

    void waterfallDataReady(const QVector<double>&power);
private:
    Ui::MainWindow *ui;
    int start_1;
    int stop_1;
    QUdpSocket *udpSocket;
    QTcpSocket *tcpSocket;
    Spectrumwidget *spectrum;

    QVector<double> pendingFreq;
    QVector<double> pendingPower;
    QHash<double, int> pendingIndexMap;
    bool pendingDirty = false;
    QTimer *emitTimer;

    Waterfallwidget *waterfall;
private slots:
    void updateSpectrum(const QVector<double> &freq,const QVector<double> &power);
     void on_pushButton_clicked();
    void readPendingDatagrams();
     };
#endif // MAINWINDOW_H
