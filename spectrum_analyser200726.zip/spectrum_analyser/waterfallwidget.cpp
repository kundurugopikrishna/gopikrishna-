#include "waterfallwidget.h"
#include <QPainter>
#include <algorithm>
#include <cmath>

Waterfallwidget::Waterfallwidget(QWidget *parent)
    : QWidget{parent}
{

   // setMinimumHeight(200);
   // setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setMouseTracking(true);   // <-- ADD THIS: required for mouseMoveEvent to fire on hover
    //buildColorLUT();



    setMinimumHeight(200);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    buildColorLUT();

    minPowerDbm = -132.0;
    maxPowerDbm = -100.0;

    waterfallImage = QImage(std::max(1, width()), std::max(1, height()), QImage::Format_RGB32);
    waterfallImage.fill(Qt::black);

    scrollTimer = new QTimer(this);
    scrollTimer->setInterval(50); // 20 Hz
    connect(scrollTimer, &QTimer::timeout, this, [this]() {
        if (rowPending)
        {
            renderPendingRow();
            rowPending = false;
            update();
        }
    });
    scrollTimer->start();
}

void Waterfallwidget::setstartstopwaterfall(double startW, double stopW)
{
    bool rangeChanged =
        (m_lastStartfreq < 0) ||                         // first time ever called
        !qFuzzyCompare(startW, m_lastStartfreq) ||
        !qFuzzyCompare(stopW,  m_lastStopfreq);

    m_startfreq = startW;
    m_stopfreq  = stopW;

    // paintEvent's peak markers use these specific names — keep them in sync
    startFreqMHz = startW;
    stopFreqMHz  = stopW;

    if (rangeChanged)
    {
        clearWaterfall();          // wipes waterfallImage to black, clears pending row
        m_lastStartfreq = startW;
        m_lastStopfreq  = stopW;
    }
}



// void Waterfallwidget::setPowerRange(double minDbm, double maxDbm)
// {
//     minPowerDbm = minDbm;
//     maxPowerDbm = maxDbm;
// }

// --------------------------------------------------------------------
// Precompute the color gradient once (e.g. blue -> green -> yellow -> red)
// so per-pixel work at render time is just an array lookup, not math.
// --------------------------------------------------------------------
void Waterfallwidget::buildColorLUT()
{
    constexpr int lutSize = 256;
    colorLUT.resize(lutSize);

    for (int i = 0; i < lutSize; i++)
    {
        double t = static_cast<double>(i) / (lutSize - 1); // 0..1

        int r, g, b;
        if (t < 0.25) {
            double s = t / 0.25;
            r = 0; g = 0; b = static_cast<int>(128 + s * 127);       // black -> blue
        } else if (t < 0.5) {
            double s = (t - 0.25) / 0.25;
            r = 0; g = static_cast<int>(s * 255); b = static_cast<int>(255 - s * 127); // blue -> green
        } else if (t < 0.75) {
            double s = (t - 0.5) / 0.25;
            r = static_cast<int>(s * 255); g = 255; b = 0;           // green -> yellow
        } else {
            double s = (t - 0.75) / 0.25;
            r = 255; g = static_cast<int>(255 - s * 255); b = 0;     // yellow -> red
        }

        colorLUT[i] = qRgb(r, g, b);
    }
}

QRgb Waterfallwidget::powerToColor(double dbm) const
{
    double t = (dbm - minPowerDbm) / (maxPowerDbm - minPowerDbm);
    t = std::clamp(t, 0.0, 1.0);
    int idx = static_cast<int>(t * (colorLUT.size() - 1));
    return colorLUT[idx];
}

// --------------------------------------------------------------------
// Called on every incoming packet — cheap, just buffers the latest row.
// Actual rendering/scrolling only happens on the throttled timer.
// --------------------------------------------------------------------
void Waterfallwidget::addWaterfallRow(double startFreqMHz, double stopFreqMHz,
                                      const QVector<double> &powerdBm)
{



  //  qDebug()<<"startFreqMHz"<<startFreqMHz<<powerdBm;

   // qDebug()<<"hi";
    if (powerdBm.isEmpty())
        return;


  //  qDebug()<<"hidfghjkl";

    pendingRowPower = powerdBm;   // just replace the buffer, cheap copy
    pendingStartFreqMHz = startFreqMHz;
    pendingStopFreqMHz  = stopFreqMHz;
    rowPending = true;
}

/*void Waterfallwidget::powerUpdate(const QVector<double> &powerDbm)
{
    if (powerDbm.isEmpty())
        return;

    // Reuse the existing buffering path — cheap, no image work here.
    // Actual rendering happens on the throttled scrollTimer as before.
    pendingRowPower = powerDbm;
    pendingStartFreqMHz = m_startfreq;
    pendingStopFreqMHz  = m_stopfreq;
    rowPending = true;
}*/

/*void Waterfallwidget::setstartstopwaterfall(double startW, double stopW)
{
    bool rangeChanged =
        (m_lastStartfreq < 0) ||                         // first time
        !qFuzzyCompare(static_cast<double>(startW), static_cast<double>(m_lastStartfreq)) ||
        !qFuzzyCompare(static_cast<double>(stopW),  static_cast<double>(m_lastStopfreq));

    m_startfreq = startW;
    m_stopfreq  = stopW;

    if (rangeChanged)
    {
        clearWaterfall();
        m_lastStartfreq = startW;
        m_lastStopfreq  = stopW;
    }
}*/
void Waterfallwidget::clearWaterfall()
{
    int w = std::max(1, width());
    int h = std::max(1, height());

    waterfallImage = QImage(w, h, QImage::Format_RGB32);
    waterfallImage.fill(Qt::black);

    pendingRowPower.clear();
    rowPending = false;

    update();  // one-off full repaint to show the cleared/black waterfall immediately
}
// --------------------------------------------------------------------
// Scrolls the image down by 1 row and draws the new row at the top.
// This is the only place that touches the QImage — runs at throttled rate.
// --------------------------------------------------------------------
void Waterfallwidget::renderPendingRow()
{
    if (waterfallImage.isNull() || pendingRowPower.isEmpty())
        return;

    int w = waterfallImage.width();
    int h = waterfallImage.height();
    if (w <= 0 || h <= 0)
        return;

    // 1. Scroll existing rows down by 1 pixel.
    //    Copy rows [0 .. h-2] into [1 .. h-1], moving everything down.
    //    QImage::scanLine gives direct pixel access — much faster than
    //    per-pixel getPixel/setPixel calls.
    for (int y = h - 1; y > 0; y--)
    {
        memcpy(waterfallImage.scanLine(y), waterfallImage.scanLine(y - 1),
               static_cast<size_t>(waterfallImage.bytesPerLine()));
    }

    // 2. Draw the new row at the top (y = 0), mapping frequency bins to
    //    image columns and looking up colors via the LUT.
    QRgb *topRow = reinterpret_cast<QRgb *>(waterfallImage.scanLine(0));

    int numPoints = pendingRowPower.size();
    double freqSpan = pendingStopFreqMHz - pendingStartFreqMHz;

    for (int x = 0; x < w; x++)
    {
        double freqAtPixel = pendingStartFreqMHz + (freqSpan * x) / w;
        int dataIdx = 0;
        if (numPoints > 1 && freqSpan > 0)
        {
            double ratio = (freqAtPixel - pendingStartFreqMHz) / freqSpan;
            dataIdx = static_cast<int>(ratio * (numPoints - 1));
            dataIdx = std::clamp(dataIdx, 0, numPoints - 1);
        }
        topRow[x] = powerToColor(pendingRowPower[dataIdx]);
    }
}

// --------------------------------------------------------------------
// paintEvent just blits the pre-rendered image — cheap, no per-pixel work here.
// --------------------------------------------------------------------
// void Waterfallwidget::paintEvent(QPaintEvent *)
// {
//     QPainter painter(this);
//     painter.fillRect(rect(), QColor("#1765f5"));
//     painter.setRenderHint(QPainter::Antialiasing, false);

//     int w = width();
//     int h = height();

//     int colorBarWidth = 10;          // width of rainbow bar
//     int labelWidth = 30;             // width for dB labels

//     int timestampHeight = 20;        // height of timestamp row
//     int rowGap = 30;                 // empty gap between rows
//     rowHeight = timestampHeight + rowGap;

//     //  Determine which rows to draw
//     int rowsToShow = rowHeight > 0 ? h / rowHeight : 0;
//     int startRow = qMax(0, spectrumHistory.size() - rowsToShow);

//     QList<QVector<int>> visibleHistory = spectrumHistory.mid(startRow);
//     QStringList visibleTimes = timeHistory.mid(startRow);

//     const double minYdB = -132.0;
//     const double maxYdB = -12.0;

//     // --------------------------------------------
//     // Plot Rectangle
//     // --------------------------------------------
//     const int leftMargin = 40;
//     const int rightMargin = 10;
//     const int topMargin = 20;
//     const int bottomMargin = 25;

//     int plotXStart = leftMargin;
//     int plotWidth = w - leftMargin - rightMargin;   // now matches plotRect's width

//     QRectF plotRect(leftMargin, topMargin,
//                     w - leftMargin - rightMargin,
//                     h - topMargin - bottomMargin);

//     /* ===============================
//      * Frequency Axis
//      * =============================== */
//     painter.setPen(Qt::white);                       // was Qt::NoPen -> labels were invisible
//     painter.setFont(QFont("Arial", 8, QFont::Bold));

//     painter.drawText(plotRect.left()+2, plotRect.topLeft().y(),
//                      QString::number(m_startfreq, 'f', 2));
//     painter.drawText(plotRect.right() - 40, plotRect.topRight().y(),
//                      QString::number(m_stopfreq, 'f', 2));

//     //  Draw waterfall rows
//     int row = 0;
//     for (const QVector<int> &spectrum : visibleHistory)
//     {
//         if (spectrum.isEmpty() || spectrum.size() < 2)
//             continue;

//         int xStep = plotWidth / spectrum.size();

//         for (int i = 0; i < spectrum.size(); ++i)
//         {
//             int x = plotXStart + i * xStep;

//             float norm = spectrum[i] / 255.0f;
//             norm = qBound(0.0f, norm, 1.0f);

//             QColor color;
//             color.setHsvF((1.0 - norm) * 0.7, 0.8, 1.0); // rainbow scale

//             painter.fillRect(x, row * rowHeight + yOffset, xStep, rowHeight, color); // was commented out
//         }

//         //  Draw timestamp on left side
//         if (row < visibleTimes.size())
//         {
//             int textX = colorBarWidth + labelWidth + 5;
//             int textY = row * rowHeight + yOffset + (timestampHeight / 2) + 4;

//             painter.setPen(Qt::white);
//             painter.setFont(QFont("Arial", 8, QFont::Bold));

//             painter.drawText(textX, textY, visibleTimes[row]);
//         }
//         row++;
//     }

//     //  Rainbow color scale on LEFT
//     QRect colorRect(labelWidth, 2, colorBarWidth, h - 5);

//     QLinearGradient gradient(colorRect.topLeft(), colorRect.bottomLeft());
//     gradient.setColorAt(0.0, Qt::red);
//     gradient.setColorAt(0.2, Qt::yellow);
//     gradient.setColorAt(0.4, Qt::green);
//     gradient.setColorAt(0.6, Qt::cyan);
//     gradient.setColorAt(0.8, Qt::blue);
//     gradient.setColorAt(1.0, Qt::darkBlue);

//     painter.setBrush(gradient);
//     painter.setPen(Qt::NoPen);
//     painter.drawRect(colorRect);

//     //  Dynamic dB labels
//     painter.setPen(Qt::white);
//     QFont font = painter.font();
//     font.setPointSize(8);
//     painter.setFont(font);

//     int numLabels = std::max(13, h / 40);
//     int stepValue = 10;
//     int maxValue = 0;

//     for (int i = 0; i < numLabels; ++i) {
//         int value = maxValue - i * stepValue;
//         int y = colorRect.top() + i * (colorRect.height() / (numLabels - 1));
//         painter.drawText(labelWidth - 28, y + 5, QString::number(value));
//     }

//     // Border around color bar
//     painter.setPen(Qt::gray);
//     painter.setBrush(Qt::NoBrush);
//     painter.drawRect(colorRect);

//     // ------------------------------
//     // Peak fall-down markers
//     // ------------------------------
//     const double barWidth = 0.4;
//     const double fallSpeed = 1.5;   // pixels per frame (tune this)

//     if (peakFallY.size() != peakFreq.size())
//     {
//         peakFallY.resize(peakFreq.size());
//         for (int i = 0; i < peakFallY.size(); ++i)
//             peakFallY[i] = plotRect.top();   // start from top
//     }

//     painter.setPen(Qt::NoPen);
//     painter.setBrush(Qt::green);

//     for (int i = 0; i < peakFreq.size(); ++i)
//     {
//         // ---- X position ----
//         double xCenter = plotRect.left() + (peakFreq[i] - startFreqMHz) /
//                                                (stopFreqMHz - startFreqMHz) * plotRect.width();

//         // ---- Target Y (final peak) ----
//         double yPeak = plotRect.top() + (maxYdB - peakAmp[i]) /
//                                             (maxYdB - minYdB) * plotRect.height();

//         xCenter = qBound((double)plotRect.left(), xCenter, (double)plotRect.right());
//         yPeak   = qBound((double)plotRect.top(), yPeak, (double)plotRect.bottom());

//         // ---- Reset when new higher peak arrives ----
//         if (yPeak < peakFallY[i])
//         {
//             peakFallY[i] = plotRect.top();
//         }

//         // ---- Slow fall animation ----
//         if (peakFallY[i] < yPeak)
//         {
//             peakFallY[i] += fallSpeed;
//         }

//         peakFallY[i] = qMin(peakFallY[i], yPeak);

//         // ---- Draw vertical peak line ----
//         QRectF barRect(xCenter - barWidth * 0.5,
//                        plotRect.top(), barWidth,
//                        peakFallY[i] - plotRect.top());

//         painter.drawRect(barRect);
//     }
// }
void Waterfallwidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.fillRect(rect(), QColor("#1765f5"));

    // --- FIX: actually draw the scrolling waterfall image that
    //     renderPendingRow() has been writing into. This was missing,
    //     which is why nothing ever appeared despite data arriving. ---
    painter.drawImage(rect(), waterfallImage, waterfallImage.rect());

    painter.setRenderHint(QPainter::Antialiasing, false);

    int w = width();
    int h = height();

    int colorBarWidth = 10;          // width of rainbow bar
    int labelWidth = 30;             // width for dB labels

    int timestampHeight = 20;        // height of timestamp row
    int rowGap = 30;                 // empty gap between rows
    rowHeight = timestampHeight + rowGap;

    const double minYdB = -132.0;
    const double maxYdB = -12.0;

    // --------------------------------------------
    // Plot Rectangle
    // --------------------------------------------
    const int leftMargin = 40;
    const int rightMargin = 10;
    const int topMargin = 20;
    const int bottomMargin = 25;

    QRectF plotRect(leftMargin, topMargin,
                    w - leftMargin - rightMargin,
                    h - topMargin - bottomMargin);

    /* ===============================
     * Frequency Axis
     * =============================== */
    painter.setPen(Qt::white);
    painter.setFont(QFont("Arial", 8, QFont::Bold));

    painter.drawText(plotRect.left()+2, plotRect.topLeft().y(),
                     QString::number(m_startfreq, 'f', 2));
    painter.drawText(plotRect.right() - 40, plotRect.topRight().y(),
                     QString::number(m_stopfreq, 'f', 2));

    // --- REMOVED: the spectrumHistory-based row-drawing loop that was here.
    //     spectrumHistory is never populated anywhere in this code, so that
    //     loop always did nothing — the drawImage() call above now handles
    //     drawing the actual waterfall rows instead. ---

    //  Rainbow color scale on LEFT
    QRect colorRect(labelWidth, 2, colorBarWidth, h - 5);

    QLinearGradient gradient(colorRect.topLeft(), colorRect.bottomLeft());
    gradient.setColorAt(0.0, Qt::red);
    gradient.setColorAt(0.2, Qt::yellow);
    gradient.setColorAt(0.4, Qt::green);
    gradient.setColorAt(0.6, Qt::cyan);
    gradient.setColorAt(0.8, Qt::blue);
    gradient.setColorAt(1.0, Qt::darkBlue);

    painter.setBrush(gradient);
    painter.setPen(Qt::NoPen);
    painter.drawRect(colorRect);

    //  Dynamic dB labels
    painter.setPen(Qt::white);
    QFont font = painter.font();
    font.setPointSize(8);
    painter.setFont(font);

    int numLabels = std::max(13, h / 40);
    int stepValue = 10;
    int maxValue = 0;

    for (int i = 0; i < numLabels; ++i) {
        int value = maxValue - i * stepValue;
        int y = colorRect.top() + i * (colorRect.height() / (numLabels - 1));
        painter.drawText(labelWidth - 28, y + 5, QString::number(value));
    }

    // Border around color bar
    painter.setPen(Qt::gray);
    painter.setBrush(Qt::NoBrush);
    painter.drawRect(colorRect);

    // ------------------------------
    // Peak fall-down markers
    // ------------------------------
    const double barWidth = 0.4;
    const double fallSpeed = 1.5;

    if (peakFallY.size() != peakFreq.size())
    {
        peakFallY.resize(peakFreq.size());
        for (int i = 0; i < peakFallY.size(); ++i)
            peakFallY[i] = plotRect.top();
    }

    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::green);

    for (int i = 0; i < peakFreq.size(); ++i)
    {
        double xCenter = plotRect.left() + (peakFreq[i] - startFreqMHz) /
                                               (stopFreqMHz - startFreqMHz) * plotRect.width();

        double yPeak = plotRect.top() + (maxYdB - peakAmp[i]) /
                                            (maxYdB - minYdB) * plotRect.height();

        xCenter = qBound((double)plotRect.left(), xCenter, (double)plotRect.right());
        yPeak   = qBound((double)plotRect.top(), yPeak, (double)plotRect.bottom());

        if (yPeak < peakFallY[i])
        {
            peakFallY[i] = plotRect.top();
        }

        if (peakFallY[i] < yPeak)
        {
            peakFallY[i] += fallSpeed;
        }

        peakFallY[i] = qMin(peakFallY[i], yPeak);

        QRectF barRect(xCenter - barWidth * 0.5,
                       plotRect.top(), barWidth,
                       peakFallY[i] - plotRect.top());

        painter.drawRect(barRect);
    }
}
void Waterfallwidget::mouseMoveEvent(QMouseEvent *event)
{
    mousePos = event->pos();
    mouseInside = true;

    if (spectrumHistory.isEmpty() || timeHistory.isEmpty() || rowHeight <= 0)
        return;

    const int leftMargin = 40;
    const int rightMargin = 10;
    const int topMargin = 20;
    const int bottomMargin = 25;

    QRectF plotRect(leftMargin, topMargin,
                    width() - leftMargin - rightMargin,
                    height() - topMargin - bottomMargin);

    if (!plotRect.contains(mousePos))
        return;

    //  Determine row index
    int rowIndex = static_cast<int>((mousePos.y() - plotRect.top()) / rowHeight);
    rowIndex = qBound(0, rowIndex, timeHistory.size() - 1);

    emit waterfallTimestamp(timeHistory[rowIndex]);
}

void Waterfallwidget::leaveEvent(QEvent *)
{
    mouseInside = false;
}

// --------------------------------------------------------------------
// On resize, rebuild the image at the new size (old history is lost,
// which is standard/expected behavior for a waterfall on resize).
// --------------------------------------------------------------------
void Waterfallwidget::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);

    int newW = std::max(1, width());
    int newH = std::max(1, height());

    QImage newImage(newW, newH, QImage::Format_RGB32);
    newImage.fill(Qt::black);
    waterfallImage = newImage;
}
