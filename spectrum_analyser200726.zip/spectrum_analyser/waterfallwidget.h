#ifndef WATERFALLWIDGET_H
#define WATERFALLWIDGET_H

#include <QWidget>
#include <QImage>
#include <QTimer>
#include <QVector>
#include <QList>
#include <QStringList>
#include <QColor>
#include <QMouseEvent>

class Waterfallwidget : public QWidget
{
    Q_OBJECT
public:
    explicit Waterfallwidget(QWidget *parent = nullptr);
void setstartstopwaterfall(double startW, double stopW);
    void addWaterfallRow(double startFreqMHz, double stopFreqMHz,
                         const QVector<double> &powerdBm);
  //  void powerUpdate(const QVector<double> &powerDbm);
  //  void setstartstopwaterfall(double startW, double stopW);
    void clearWaterfall();

signals:
    void waterfallTimestamp(const QString &timestamp);   // <-- FIX: was missing

protected:
    void paintEvent(QPaintEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;    // <-- FIX: was missing
    void leaveEvent(QEvent *event) override;              // <-- FIX: was missing

private:
    QImage waterfallImage;
    QVector<QRgb> colorLUT;
    double minPowerDbm = -132.0;
    double maxPowerDbm = -80.0;

    double m_startfreq = 0;
    double m_stopfreq  = 0;
    double m_lastStartfreq = -1;
    double m_lastStopfreq  = -1;

    // FIX: these are used in paintEvent but weren't declared
    double startFreqMHz = 0;
    double stopFreqMHz  = 0;

    QVector<double> pendingRowPower;
    double pendingStartFreqMHz = 0;
    double pendingStopFreqMHz  = 0;
    bool rowPending = false;

    QTimer *scrollTimer;

    // FIX: waterfall history + layout state used in paintEvent
    QList<QVector<int>> spectrumHistory;
    QStringList timeHistory;
    int rowHeight = 0;
    int yOffset = 0;

    // FIX: peak fall-down marker state used in paintEvent
    QVector<double> peakFreq;
    QVector<double> peakAmp;
    QVector<double> peakFallY;

    // FIX: mouse tracking state used in mouseMoveEvent/leaveEvent
    QPoint mousePos;
    bool mouseInside = false;

    void buildColorLUT();
    QRgb powerToColor(double dbm) const;
    void renderPendingRow();
};

#endif
